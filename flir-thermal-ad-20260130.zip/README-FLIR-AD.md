# FLIR Thermal Ad - Proyecto Completo

## 📦 Contenido del Proyecto

```
flir-thermal-ad/
├── flir-thermal-ad.html          # Versión HTML5 estándar
├── flir-thermal-ad-amp.html      # Versión AMPHTML (Google Ads compatible)
├── normal.webp                   # Imagen vista normal (13KB)
├── thermal.webp                  # Imagen vista térmica (10KB)
├── camara.webp                   # Cursor de cámara (9KB)
└── README.md                     # Este archivo
```

**Tamaño total del proyecto:** ~52KB (muy por debajo del límite de 150KB)

## 🎯 Características del Ad

### Interactividad
- **Efecto termográfico**: Al mover el cursor, se revela la imagen térmica
- **Cursor personalizado**: Imagen de cámara FLIR que sigue el mouse
- **Detección de punto caliente**: Zona específica que activa un mensaje de alerta
- **CTA visible**: Botón negro "Ver Cámaras FLIR →" visible desde el inicio
- **Responsive**: Funciona en desktop y mobile (touch events)

### Tracking de Eventos
- Inicio de interacción (mouse enter / touch)
- Detección de falla térmica
- Clicks en CTA
- Compatible con Google Analytics (gtag) y Google Web Designer (Enabler)

## 🚀 Implementación

### Opción 1: HTML5 Estándar (flir-thermal-ad.html)
Para uso en sitios web regulares o plataformas que aceptan HTML5.

```html
<!-- Simplemente sube todos los archivos al servidor -->
<!-- Asegúrate de que las rutas de las imágenes sean correctas -->
```

### Opción 2: AMPHTML (flir-thermal-ad-amp.html)
Para Google Ads, Display & Video 360, y otras plataformas que requieren AMP4ADS.

**Características AMP:**
- ✅ Usa `<html ⚡4ads>` declaration
- ✅ Scripts AMP requeridos incluidos
- ✅ Usa `<amp-img>` para imágenes
- ✅ CSS inline en `<style amp-custom>`
- ✅ Boilerplate AMP4ADS incluido
- ✅ JavaScript vanilla (sin librerías externas)

## 📋 Checklist de Validación

### Antes de Subir a Google Ads:

1. **Validar AMPHTML**
   - Usa el validador oficial: https://validator.ampproject.org/
   - O instala la extensión de Chrome: AMP Validator

2. **Verificar Tamaño**
   ```bash
   # Verificar que el total no supere 150KB
   du -sh flir-thermal-ad-amp.html *.webp
   ```

3. **Probar Localmente**
   - Abre el archivo en un navegador
   - Verifica que todas las imágenes carguen
   - Prueba la interacción del cursor
   - Verifica que el botón CTA funcione

4. **Verificar URLs**
   - CTA apunta a: `https://www.colvinycia.cl/collections/camaras-termicas-flir`
   - Asegúrate de que la URL sea la correcta

## 🎨 Personalización

### Cambiar la Zona de Detección
En el JavaScript, modifica la línea:
```javascript
const detectionZone = { x: 70, y: 50, radius: 40 };
// x, y: posición en píxeles desde la esquina superior izquierda
// radius: radio de detección en píxeles
```

### Cambiar el Radio de Revelación
```javascript
const revealRadius = 60; // Tamaño del círculo de revelación
```

### Modificar el Tamaño del Cursor
En el CSS:
```css
.thermal-cursor {
  width: 120px;  /* Ancho de la cámara */
  height: 120px; /* Alto de la cámara */
}
```

### Cambiar el Color del Botón
```css
.cta {
  background: #000;  /* Color de fondo */
  color: #fff;       /* Color del texto */
  border: 1px solid rgba(255, 255, 255, 0.2);
}
```

## 📊 Tracking y Analytics

### Google Analytics (gtag.js)
El ad ya incluye tracking automático. Solo necesitas tener gtag.js en tu página:

```html
<!-- En la página donde se muestre el ad -->
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'GA_MEASUREMENT_ID');
</script>
```

### Eventos Trackeados:
- `interaction/start/mouse_enter` - Usuario entra al ad
- `interaction/start/touch` - Usuario toca el ad (mobile)
- `detection/fault_found/thermal_reveal` - Detecta el punto caliente
- `cta/click/ver_camaras` - Click en el botón CTA

## 🔧 Troubleshooting

### Las imágenes no cargan
- Verifica que los archivos `.webp` estén en el mismo directorio
- Revisa las rutas en el HTML (deben ser relativas: `./nombre.webp`)

### El cursor no aparece
- Verifica que `camara.webp` exista y sea accesible
- Asegúrate de que la imagen tenga transparencia en el display

### El ad no pasa la validación AMP
- Usa el validador: https://validator.ampproject.org/
- Revisa que no hayas agregado CSS o JS no permitido
- Verifica que todas las imágenes usen `<amp-img>`

### El botón CTA no funciona
- Verifica que la URL sea correcta y accesible
- En algunos navegadores, `window.open()` puede ser bloqueado
- Asegúrate de que `target="_blank"` esté presente

## 📱 Compatibilidad

- ✅ Chrome/Edge (últimas 2 versiones)
- ✅ Firefox (últimas 2 versiones)
- ✅ Safari (últimas 2 versiones)
- ✅ Mobile Safari (iOS 12+)
- ✅ Chrome Mobile (Android 8+)

## 📄 Licencia y Uso

Este ad fue creado para **Colvin y Cia** para promocionar cámaras térmicas FLIR.

---

**Desarrollado por:** Rafael Mascayano  
**Fecha:** Enero 2026  
**Versión:** 1.0
